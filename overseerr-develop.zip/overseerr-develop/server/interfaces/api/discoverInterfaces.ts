export interface GenreSliderItem {
  id: number;
  name: string;
  backdrops: string[];
}
