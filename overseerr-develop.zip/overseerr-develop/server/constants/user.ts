export enum UserType {
  PLEX = 1,
  LOCAL = 2,
}
