# Pushbullet

## Configuration

### Access Token

[Create an access token](https://www.pushbullet.com/#settings) and set it here to grant Overseerr access to the Pushbullet API.
