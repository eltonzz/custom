# Slack

## Configuration

### Webhook URL

Simply [create a webhook](https://my.slack.com/services/new/incoming-webhook/) and enter the URL in this field.

{% hint style="info" %}
Please refer to the [Slack API documentation](https://api.slack.com/messaging/webhooks) for more details on configuring these notifications.
{% endhint %}
