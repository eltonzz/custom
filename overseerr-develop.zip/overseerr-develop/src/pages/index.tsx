import React from 'react';
import type { NextPage } from 'next';
import Discover from '../components/Discover';

const Index: NextPage = () => {
  return <Discover />;
};

export default Index;
